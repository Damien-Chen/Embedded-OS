/*
*********************************************************************************************************
*                                            EXAMPLE CODE
*
*               This file is provided as an example on how to use Micrium products.
*
*               Please feel free to use any application code labeled as 'EXAMPLE CODE' in
*               your application products.  Example code may be used as is, in whole or in
*               part, or may be used as a reference only. This file can be modified as
*               required to meet the end-product requirements.
*
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*
*               You can find our product's user manual, API reference, release notes and
*               more information at https://doc.micrium.com.
*               You can contact us at www.micrium.com.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                              uC/OS-II
*                                            EXAMPLE CODE
*
* Filename : main.c
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                            INCLUDE FILES
*********************************************************************************************************
*/

#include  <cpu.h>
#include  <lib_mem.h>
#include  <os.h>

#include  "app_cfg.h"


/*
*********************************************************************************************************
*                                            LOCAL DEFINES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                       LOCAL GLOBAL VARIABLES
*********************************************************************************************************
*/

static  OS_STK  StartupTaskStk[APP_CFG_STARTUP_TASK_STK_SIZE];
#define TASK_STACKSIZE 2048
//tcb_ext_info task_info_array[] = {
//    {0},{0}
//};
/*
*********************************************************************************************************
*                                         FUNCTION PROTOTYPES
*********************************************************************************************************
*/

static  void  StartupTask (void  *p_arg);
static  void  task1(void* p_arg);
static  void  task2(void* p_arg);
static  void  starttask(char* task_name);
static  void  task3(void* p_arg);
static  void  mywait(int* tick);

/*
*********************************************************************************************************
*                                                main()
*
* Description : This is the standard entry point for C code.  It is assumed that your code will call
*               main() once you have performed all necessary initialization.
*
* Arguments   : none
*
* Returns     : none
*
* Notes       : none
*********************************************************************************************************
*/

int  main (void)
{
#if OS_TASK_NAME_EN > 0u
    CPU_INT08U  os_err;
#endif


    CPU_IntInit();

    Mem_Init();                                                 /* Initialize Memory Managment Module                   */
    CPU_IntDis();                                               /* Disable all Interrupts                               */
    CPU_Init();                                                 /* Initialize the uC/CPU services                       */
    
    OutFileInit();

    OSInit();                                                   /* Initialize uC/OS-II                                  */

    InputFile();
    /*Initialize Output File*/
    //OutFileInit();

    /*Input File*/
    //InputFile();

    Task_STK = malloc(TASK_NUMBER * sizeof(int*));

    int n;
    for (n = 0; n < TASK_NUMBER; n++) {
        Task_STK[n] = malloc(TASK_STACKSIZE * sizeof(int));
    }


/*
#if OS_TASK_NAME_EN > 0u
    OSTaskNameSet(         APP_CFG_STARTUP_TASK_PRIO,
                  (INT8U *)"Startup Task",
                           &os_err);
#endif
*/
int i = 0;
while (n != 0) { // n = task_number
    OSTaskCreateExt(task3,
        &TaskParameter[i],
        &Task_STK[i][TASK_STACKSIZE - 1],
        TaskParameter[i].TaskPriority,
        TaskParameter[i].TaskID,
        &Task_STK[i][0],
        TASK_STACKSIZE,
        &TaskParameter[i],
        (OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR),
        TaskParameter[i].TaskArriveTime,
        TaskParameter[i].TaskPeriodic
    );
    i++;
    n--;
}
printf("\n");

INT8U err;

//R1 = OSMutexCreate(R1_PRIO, &err);
//R2 = OSMutexCreate(R2_PRIO, &err);
R1 = OSSemCreate(1);
R2 = OSSemCreate(1);
OSStart();                                                  /* Start multitasking (i.e. give control to uC/OS-II)   */

while (DEF_ON) {                                            /* Should Never Get Here.                               */
    ;
}
}


/*
*********************************************************************************************************
*                                            STARTUP TASK
*
* Description : This is an example of a startup task.  As mentioned in the book's text, you MUST
*               initialize the ticker only once multitasking has started.
*
* Arguments   : p_arg   is the argument passed to 'StartupTask()' by 'OSTaskCreate()'.
*
* Returns     : none
*
* Notes       : 1) The first line of code is used to prevent a compiler warning because 'p_arg' is not
*                  used.  The compiler should not generate any code for this statement.
*********************************************************************************************************
*/
// PA3
void mywait(int tick) {
#if OS_CRITICAL_METHOD == 3
    OS_CPU_SR cpu_sr = 0;
#endif
    int now, exit;
    // now = 7
    // tick = 5
    // exit = 12
    OS_ENTER_CRITICAL();
    now = OSTimeGet();
    exit = now + tick;
    OS_EXIT_CRITICAL();

    while (1) {
      //  printf("%d : using shared resource\n", OSTimeGet());
        if (exit - OSTimeGet())
           // printf("%d end shared resource\n", OSTimeGet());
            break;
    }
}
void task3(void* p_arg) {
    INT8U err;
    task_para_set* task_data;
    task_data = p_arg;
    // initialize data
    OSTCBCur->OSTCBCnt = 0;
    OSTCBCur->Ori_arr_time = task_data->TaskArriveTime;
    OSTCBCur->exetime = task_data->TaskExecutionTime;
    OSTCBCur->rem_exetime = OSTCBCur->exetime;
    OSTCBCur->task_complete_num = 0;
    // to record original priority
    int original_prio = task_data->TaskPriority;
    while (1) {
        OSTCBCur->arrival_time = OSTimeGet();
      
        while (OSTCBCur->rem_exetime > 0) {
            if (task_data->R1_LockTime != 0 && OSTimeGet() == (task_data->R1_LockTime + OSTCBCur->arrival_time)) {
                // if the task`s priority is lower than resource
                // change it to equal to the resoruce
                if (task_data->TaskPriority < R1_PRIO) {
                    OSTaskChangePrio(original_prio, R1_PRIO);
                }
                OSSemPend(R1, 0, &err);
                
                
                printf("%2d     task %d get R1\t\t\t\t %d to %d\n", OSTimeGet(), task_data->TaskID, task_data->TaskPriority, R1_PRIO);
                if (Output_err = fopen_s(&Output_fp, "./Output.txt", "a") == 0) {
                    fprintf(Output_fp, "%2d\t   task %d get R1\t\t\t\t\t\t %d to %d\n", OSTimeGet(), task_data->TaskID, task_data->TaskPriority, R1_PRIO);
                    fclose(Output_fp);
                }

                // to record access time
                OSTCBCur->R1_time = task_data->R1_UnlockTime - task_data->R1_LockTime;
                // same function as mywait() but using local
                // easy to manage
                while (1) {
                    if (OSTCBCur->R1_time == 0) {
                        break;
                    }
                }
                printf("%2d     task %d release R1\t\t\t %d to %d\n", OSTimeGet(), task_data->TaskID, R1_PRIO, original_prio);
                if (Output_err = fopen_s(&Output_fp, "./Output.txt", "a") == 0) {
                    fprintf(Output_fp, "%2d\t   task %d release R1\t\t\t\t\t %d to %d\n", OSTimeGet(), task_data->TaskID, R1_PRIO, original_prio);
                    fclose(Output_fp);
                }

          
                if (task_data->TaskPriority != original_prio) {
                    OSTaskChangePrio(task_data->TaskPriority, original_prio);
                }
                OSSemPost(R1);

            }
            if (task_data->R2_LockTime != 0 && OSTimeGet() == (task_data->R2_LockTime + OSTCBCur->arrival_time)) {

                // if the task`s priority is lower than resource
                // change it to equal to the resoruce
                if (task_data->TaskPriority < R2_PRIO) {
                    OSTaskChangePrio(original_prio, R2_PRIO);
                }
                OSSemPend(R2, 0, &err);

              
                printf("%2d     task %d get R2\t\t\t\t %d to %d\n", OSTimeGet(), task_data->TaskID, task_data->TaskPriority, R2_PRIO);
                if (Output_err = fopen_s(&Output_fp, "./Output.txt", "a") == 0) {
                    fprintf(Output_fp, "%2d\t   task %d get R2\t\t\t\t\t\t %d to %d\n", OSTimeGet(), task_data->TaskID, task_data->TaskPriority, R2_PRIO);
                    fclose(Output_fp);
                }
                
                // to record access time
                OSTCBCur->R2_time = task_data->R2_UnlockTime - task_data->R2_LockTime;

                // same function as mywait() but using local
                // easy to manage
                while (1) {
                    if (OSTCBCur->R2_time == 0) {
                        break;
                    }
                }

                printf("%2d     task %d release R2\t\t\t %d to %d\n", OSTimeGet(), task_data->TaskID, R2_PRIO, original_prio);
                if (Output_err = fopen_s(&Output_fp, "./Output.txt", "a") == 0) {
                    fprintf(Output_fp, "%2d\t   task %d release R2\t\t\t\t\t %d to %d\n", OSTimeGet(), task_data->TaskID, R2_PRIO, original_prio);
                    fclose(Output_fp);
                }

                // resume task original priority
                if (task_data->TaskPriority != original_prio) {
                    OSTaskChangePrio(task_data->TaskPriority, original_prio);
                }
                OSSemPost(R2);
         
            }
        }
        OS_ENTER_CRITICAL();
        OSTCBCur->rem_exetime = OSTCBCur->exetime;
        OSTCBCur->task_complete_num += 1;
        OS_EXIT_CRITICAL();
        OSTimeDly(OSTCBCur->rem_period);
    }
}





void starttask(char* task_name, task_para_set* task_data) {
    while (1) {
        OSTCBCur->arrival_time = OSTimeGet();
        while (OSTCBCur->rem_exetime > 0) {
           
          // do nothing
        }

        OS_ENTER_CRITICAL();

        OSTCBCur->rem_exetime = OSTCBCur->exetime;
        OSTCBCur->task_complete_num += 1;
        OSTCBCur->complete_time = OSTimeGet();

        OS_EXIT_CRITICAL();
       // printf("%d read to delay %d\n", OSTCBCur->OSTCBId, OSTCBCur->rem_period);
        OSTimeDly(OSTCBCur->rem_period);
    }
}

void task1(void* p_arg) {
    task_para_set* task_data;
    task_data = p_arg;
    // initialize user-def TCB parameter
    OSTCBCur->OSTCBCnt = 0;
    OSTCBCur->arrival_time = task_data->TaskArriveTime;
    OSTCBCur->Ori_arr_time = task_data->TaskArriveTime;
    OSTCBCur->exetime = task_data->TaskExecutionTime;
    OSTCBCur->rem_exetime = OSTCBCur->exetime;
   // OSTCBCur->period = task_data->TaskPeriodic;
   //STCBCur->rem_period = OSTCBCur->period;
    OSTCBCur->task_complete_num = 0;
    //printf("%d rem_period = %d\n", OSTCBCur->OSTCBId, OSTCBCur->rem_period);
    char* task1 = "task1";
    starttask(task1, task_data);
}

void task2(void* p_arg) {
    task_para_set* task_data;
    int i = 0;
    task_data = p_arg;
    char* task2 = "task2";

    starttask(task2, task_data);
    
}
static  void  StartupTask (void *p_arg)
{
   (void)p_arg;

    OS_TRACE_INIT();                                            /* Initialize the uC/OS-II Trace recorder               */

#if OS_CFG_STAT_TASK_EN > 0u
    OSStatTaskCPUUsageInit(&err);                               /* Compute CPU capacity with no task running            */
#endif

#ifdef CPU_CFG_INT_DIS_MEAS_EN
    CPU_IntDisMeasMaxCurReset();
#endif
    
    APP_TRACE_DBG(("uCOS-III is Running...\n\r"));

    while (DEF_TRUE) {                                          /* Task body, always written as an infinite loop.       */
        OSTimeDlyHMSM(0u, 0u, 1u, 0u);
		APP_TRACE_DBG(("Time: %d\n\r", OSTimeGet()));
    }
}

